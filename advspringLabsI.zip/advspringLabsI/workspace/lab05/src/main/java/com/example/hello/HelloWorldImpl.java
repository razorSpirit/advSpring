package com.example.hello;

public class HelloWorldImpl implements HelloWorld {
	//private Logger log = Logger.getLogger(HelloWorldImpl.class);
	@Override
	public void sayHello(String name) {
		System.out.println("Hello "+ name);
	}

}
