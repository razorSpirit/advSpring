package com.example.hello;

public interface HelloWorld {
	void sayHello(String name);
}
