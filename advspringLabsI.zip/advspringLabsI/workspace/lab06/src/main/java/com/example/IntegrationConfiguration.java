package com.example;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.handler.ServiceActivatingHandler;
import org.springframework.integration.scheduling.PollerMetadata;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHandler;
import org.springframework.scheduling.support.PeriodicTrigger;

import com.example.service.AccountService;
import com.example.service.AccountServiceImpl;

@Configuration
@EnableIntegration
public class IntegrationConfiguration {
	@Bean
	public AccountService accountService() {
		return new AccountServiceImpl();
	}

	@Bean(name= PollerMetadata.DEFAULT_POLLER)
	public PollerMetadata defaultPoller() {
		PollerMetadata pollerMetadata = new PollerMetadata();
		pollerMetadata.setTrigger(new PeriodicTrigger(100));
		return pollerMetadata;
	}
	
	@Bean
	public MessageChannel shippingChannel() {
		return new DirectChannel();
	}
	
	@Bean
	@ServiceActivator(inputChannel="shippingChannel")
	public MessageHandler activator() {
		ServiceActivatingHandler mh =
				new ServiceActivatingHandler(accountService(), "accrueInterest");
		return mh;
	}	
}
