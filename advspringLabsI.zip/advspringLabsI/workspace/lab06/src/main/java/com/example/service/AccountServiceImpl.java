package com.example.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.springframework.messaging.handler.annotation.Header;

import com.example.domain.Account;

public class AccountServiceImpl implements AccountService {

	@Override
	public void accrueInterest(Account a, @Header(name="expirationDate") Long expiry) {
		System.out.println(a);
		BigDecimal balance = a.getBalance();
		balance = balance.add(balance.multiply(new BigDecimal(0.05)));
		a.setBalance(balance);
		try {
			TimeUnit.SECONDS.sleep(10);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			System.out.println("Time elapsed after 10ms");
		}
		System.out.println("Applied 5% interest:\n"+ a);
		System.out.println("Expiration Date: "+ new Date(expiry));
		
	}

}
