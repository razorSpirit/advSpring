package com.example;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;

import org.springframework.boot.Banner.Mode;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.integration.channel.QueueChannel;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;

import com.example.domain.Account;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		SpringApplication app = new SpringApplication(DemoApplication.class);
		app.setBannerMode(Mode.OFF);
//		ApplicationContext ctx = app.run(args);	

//		MessageChannel channel =
//				ctx.getBean("shippingChannel", MessageChannel.class);
		
		QueueChannel channel = new QueueChannel(10);

		Account a = new Account();
		a.setAccountNumber(202211);
		a.setCreationDate(new Date());
		a.setCustomerNumber(11);
		a.setBalance(new BigDecimal(12000.56d));
		
		Calendar now = Calendar.getInstance();
		now.add(Calendar.DATE, 7);
		
		Message<Account> message = MessageBuilder.withPayload(a).setExpirationDate(now.getTime()).build();
		
		System.out.println("Sending first message");
		channel.send(message);
		System.out.println("Sending second message");
		channel.send(message);
		
	}
}
