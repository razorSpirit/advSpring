package com.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemStream;
import org.springframework.batch.item.ItemStreamException;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

import com.example.domain.Game;

public class MyItemReader implements ItemReader<Game>, ItemStream {
	private BufferedReader bufferedReader;
	private final int COUNT_GAME_LINES= 3;
	
	@Override
	public void open(ExecutionContext executionContext) throws ItemStreamException {		
		try {
			bufferedReader = new BufferedReader(new FileReader("C:\\Users\\Administrator\\advspring\\workspace\\lab04p3\\game.txt"));
		} catch (IOException e) {
			throw new ItemStreamException(e.getMessage());
		} 
	}

	@Override
	public void update(ExecutionContext executionContext) throws ItemStreamException {
		// TODO Auto-generated method stub

	}

	@Override
	public void close() throws ItemStreamException {
		try {
			if (bufferedReader != null)bufferedReader.close();
		} catch (IOException ex) {
			throw new ItemStreamException(ex.getMessage());
		}

	}

	@Override
	public Game read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		
		Game game = new Game();
		
		String[] lines = new String[COUNT_GAME_LINES];
		for(int i=0; i<COUNT_GAME_LINES; i++){
			lines[i] = bufferedReader.readLine();
			if(null == lines[i]){
				return null;
			}
		}
		
		game.setGameDate(lines[0]);
		game.setTeam1Name(lines[1]);
		game.setTeam2Name(lines[2]);
		
		return game;
	}

}
