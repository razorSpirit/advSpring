package com.example;

import org.apache.log4j.Logger;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.job.builder.SimpleJobBuilder;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.step.builder.SimpleStepBuilder;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.domain.Game;

@Configuration
@EnableBatchProcessing
public class BatchConfiguration {
	@Autowired
	private StepBuilderFactory stepBuilderFactory;
	@Autowired
	private JobBuilderFactory jobBuilderFactory;	
	//private Logger log = Logger.getLogger(BatchConfiguration.class);

	@Bean
	public ItemReader<Game> gameFileReader() { 
				return new MyItemReader();				
	}
	
	@Bean
	public ItemWriter<Game> gameItemWriter(){
		return new MyItemWriter();
	}
	
	@Bean
	public Step step1() {

		StepBuilder sb = stepBuilderFactory.get("step1");
		
		SimpleStepBuilder<Game, Game> ssb = sb.chunk(3);
		ssb.reader(gameFileReader());
		ssb.writer(gameItemWriter());
		
		return ssb.build();
	}
	
	@Bean
	public Job gamesToLogJob() throws Exception {
		RunIdIncrementer incrementer = new RunIdIncrementer();
		JobBuilder jb = jobBuilderFactory.get("job1");
		jb.incrementer(incrementer);
		SimpleJobBuilder sjb = jb.start(step1());
		return sjb.build();
	}
}
