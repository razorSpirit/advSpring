package com.example.shipping;

import org.springframework.stereotype.Component;

@Component(value="shipping")
public class ShippingImpl implements Shipping {

	@Override
	public double calculateDomestic(String zip) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double calculateInternational(String country) {
		// TODO Auto-generated method stub
		return 0;
	}

}
