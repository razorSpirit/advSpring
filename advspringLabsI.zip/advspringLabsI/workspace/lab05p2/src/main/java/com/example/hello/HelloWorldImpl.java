package com.example.hello;

public class HelloWorldImpl implements HelloWorld {
	//private Logger log = Logger.getLogger(HelloWorldImpl.class);
	@Override
	public String sayHello(String name) {
		return "Hello "+ name;
	}

}
