package com.example.hello;

import org.springframework.integration.annotation.MessagingGateway;

@MessagingGateway(defaultRequestChannel="shippingChannel")
public interface HelloWorld {
	public String sayHello(String name);
}
