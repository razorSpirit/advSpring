package com.example.messaging;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.ObjectMessage;

import org.apache.log4j.Logger;

import com.example.domain.PurchaseOrder;

public class ReceivePurchaseOrder implements MessageListener {
	private Logger log = Logger.getLogger(ReceivePurchaseOrder.class);

	@Override
	public void onMessage(Message message) {
		PurchaseOrder po = null;
		try {
			po = (PurchaseOrder) ((ObjectMessage) message).getObject();
			log.info("PO Number:"+po.getPoNumber() + " Amount="+po.getAmount()+" Date="+po.getPoDate());
		} catch (JMSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
